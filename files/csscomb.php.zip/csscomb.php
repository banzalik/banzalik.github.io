<?php
/**
 * CSS comb
 *
 * Работает так: $CSScomb->do_resort($your_css_code);
 *
 * Можно установить пользовательский порядок для сортировки: $CSScomb->set_sort_order($your_custom_order_in_json_format);
 * Можно использовать одномерный и двумерный массивы. В случае с двумерным массивом настроек CSS свойства будут разделены на группы пустой строкой.
 *
 * @author Viacheslav Oliyanchuk
 * @link http://csscomb.ru
 */


class CSScomb{
	private $sort_order = '';
	private $default_sort_order = '
[
	"position",
	"top",
	"right",
	"bottom",
	"left",
	"z-index",
	"float",
	"clear",
	"display",
	"visibility",
	"overflow",
	"overflow-x",
	"overflow-y",
	"overflow-style",
	"zoom",
	"clip",
	"box-sizing",
	"box-shadow",
	"-webkit-box-shadow",
	"-moz-box-shadow",
	"margin",
	"margin-top",
	"margin-right",
	"margin-bottom",
	"margin-left",
	"padding",
	"padding-top",
	"padding-right",
	"padding-bottom",
	"padding-left",
	"width",
	"height",
	"max-width",
	"max-height",
	"min-width",
	"min-height",
	"outline",
	"outline-offset",
	"outline-width",
	"outline-style",
	"outline-color",
	"border",
	"border-break",
	"border-collapse",
	"border-color",
	"border-image",
	"-webkit-border-image",
	"-moz-border-image",
	"border-top-image",
	"border-right-image",
	"border-bottom-image",
	"border-left-image",
	"border-corner-image",
	"border-top-left-image",
	"border-top-right-image",
	"border-bottom-right-image",
	"border-bottom-left-image",
	"border-fit",
	"border-length",
	"border-spacing",
	"border-style",
	"border-width",
	"border-top",
	"border-top-width",
	"border-top-style",
	"border-top-color",
	"border-right",
	"border-right-width",
	"border-right-style",
	"border-right-color",
	"border-bottom",
	"border-bottom-width",
	"border-bottom-style",
	"border-bottom-color",
	"border-left",
	"border-left-width",
	"border-left-style",
	"border-left-color",
	"border-radius",
	"-webkit-border-radius",
	"-moz-border-radius",
	"-khtml-border-radius",
	"border-top-right-radius",
	"border-top-left-radius",
	"border-bottom-right-radius",
	"border-bottom-left-radius",
	"background",
	"filter:progid:DXImageTransform.Microsoft.AlphaImageLoader",
	"background-color",
	"background-image",
	"background-repeat",
	"background-attachment",
	"background-position",
	"background-position-x",
	"background-position-y",
	"background-break",
	"background-clip",
	"background-origin",
	"background-size",
	"color",
	"table-layout",
	"caption-side",
	"empty-cells",
	"list-style",
	"list-style-position",
	"list-style-type",
	"list-style-image",
	"quotes",
	"content",
	"counter-increment",
	"counter-reset",
	"vertical-align",
	"text-align",
	"text-align-last",
	"text-decoration",
	"text-emphasis",
	"text-height",
	"text-indent",
	"text-justify",
	"text-outline",
	"text-replace",
	"text-transform",
	"text-wrap",
	"text-shadow",
	"line-height",
	"white-space",
	"white-space-collapse",
	"word-break",
	"word-spacing",
	"word-wrap",
	"letter-spacing",
	"font",
	"font-weight",
	"font-style",
	"font-variant",
	"font-size",
	"font-size-adjust",
	"font-family",
	"font-effect",
	"font-emphasize",
	"font-emphasize-position",
	"font-emphasize-style",
	"font-smooth",
	"font-stretch",
	"opacity",
	"filter:progid:DXImageTransform.Microsoft.Alpha(Opacity",
	"-ms-filter:\'progid:DXImageTransform.Microsoft.Alpha",
	"transitions",
	"resize",
	"cursor",
	"page-break-before",
	"page-break-inside",
	"page-break-after",
	"orphans",
	"widows"
]';


	
	function CSScomb(){
		$this->set_sort_order();
	}

	/**
	 * @param  {string}
	 * @return {string}
	 */
	function do_resort($css){
		return $this->parse_medias($css);
	}


	/**
	 * @param  {string}
	 * @return void
	 */
	function set_sort_order($json_array = ''){
		if($json_array!=''){
			$custom_sort_order = json_decode($json_array);
			if(is_array($custom_sort_order) AND count($custom_sort_order)>0){
				$this->sort_order = $custom_sort_order;
			}
			else $this->sort_order = json_decode($this->default_sort_order);
		}
		else $this->sort_order = json_decode($this->default_sort_order);
	}


	/**
	 * @param  {string}
	 * @return {string}
	 */
	private function parse_medias($string){
		$result = '';

		if(strpos($string, '@media')===false) $result = $this->parse_selectors($string);
		else{
			if(preg_match_all('#(.*?)@media\s(.*?)(\s*){(.*?{\s*.*?\s*}\s*)}(.*)#ism', $string, $media, PREG_SET_ORDER)){
				foreach($media as $match){
					$result .= $match[1].'@media '.$match[2].$match[3].'{';
					$result .= $this->parse_selectors($match[4]);
					$result .=  '}'.$match[5];
				}
			}
		}

		return $result;
	}


	/**
	 *
	 * @param  {string}
	 * @return {string}
	 */
	private function parse_selectors($string){
		$result = '';
		preg_match_all('#(.*?){(\s*.*?\s*)}([\s/\*[:alnum:]\.\+\=\#\-\;\:\!\(\)\@\$\%\^\&\_\|]*)#ism', $string, $match, PREG_SET_ORDER);
		foreach($match as $selector) $result .= $selector[1]."{\n".implode("\n", $this->parse_selector_rules($selector[2])).'}'.$selector[3];
		return $result;
	}


	/**
	 * @param  {string}
	 * @return {array}
	 */
	private function parse_selector_rules($string){
		$resorted = $undefined = array();

		$string = preg_replace('#/\*(.*?)\*/#smi', '', $string); // ËÁ·‡‚ÎﬂÂÏÒﬂ ÓÚ ÍÓÏÏÂÌÚ‡ËÂ‚ ‚ ‡ÏÍ‡ı Ó‰ÌÓ„Ó ÒÂÎÂÍÚÓ‡ ‚ÌÛÚË ÙË„ÛÌ˚ı ÒÍÓ·ÓÍ

		if(strpos($string, 'expression')){ // ‡Á·Ë‡ÂÏÒﬂ Ò expression ÂÒÎË ÓÌË ÔËÒÛÚÒÚ‚Û˛Ú
			$i = 0;
			$expressions = array();
			while(strpos($string, 'expression')):
				preg_match_all('#(.*)expression\((.*)\)#ism', $string, $match, PREG_SET_ORDER); // ‚˚Î‡‚ÎË‚‡ÂÏ expression
				$expressions[] = $match[0][2]; // ÒÓ·Ë‡ÂÏ ÁÌ‡˜ÂÌËﬂ expression(...)
				$string = str_replace('expression('.$match[0][2].')', 'exp'.$i++, $string);
			endwhile;
		}

		$test = trim($string);
		if(empty($test)) return array(); // ÖÒÎË ‚ÌÛÚË {} ‚ÒÂ Á‡ÍÍÓÏÂÌÚËÓ‚‡ÌÓ

		$lines = explode("\n", $string);
		if(count($lines)>1) $last = $lines[count($lines)-1]; else $last = ''; // ÒÓı‡ÌﬂÂÏ ÙÓÏ‡ÚËÓ‚‡ÌËÂ ÔÓÒÎÂ ÔÓÒÎÂ‰ÌÂ„Ó \n ÂÒÎË Ò‚ÓÈÒÚ‚‡ ·˚ÎË ÔÓ Ó‰ÌÓÏÛ Ì‡ ÒÚÓÍÂ, ‡ ÌÂ div {display: inline-block; *display: inline;}

		/*
		  ê‡Á·Ë‡ÂÏ ÒÎÛ˜‡È, ÍÓ„‰‡ ÁÌ‡˜ÂÌËÂ CSS Ò‚ÓÈÒÚ‚‡ Á‡ÔËÒ‡ÌÓ Ì‡ ÌÂÒÍÓÎ¸ÍËı ÒÚÓÍ‡ı.
		  èËÏÂ:
		  		background: url(a.png) top left no-repeat,
		 		url(b.png) center / 100% 100% no-repeat,
		  		url(c.png) white;
		*/
		krsort($lines);
		foreach($lines as $num=>$line){
			$test = trim($line);
			if(!empty($test) AND !strpos($line, ':')){ // ÂÒÎË ÒÚÓÍ‡ ÌÂ ÔÛÒÚ‡ﬂ Ë ÌÂ ÒÓ‰ÂÊËÚ ‰‚ÓÂÚÓ˜Ëﬂ, ÚÓ ÔËÒÓÂ‰ËÌﬂÂÏ ÂÂ Í ÔÂ‰˚‰Û˘ÂÈ
				$lines[$num-1] = $lines[$num-1].$lines[$num];
				unset($lines[$num]);
			}
		}
		ksort($lines);

		foreach($lines as $line){
			$l = trim($line);
			if(empty($l)) continue;

			if(strpos($line, ';')!==false) $properties = explode(";", $line); // ÂÒÎË Ì‡ Ó‰ÌÓÈ ÒÚÓÍÂ ÌÂÒÍÓÎ¸ÍÓ Á‡ÔËÒÂÈ ‡Á‰ÂÎÂÌÌ˚ı ;
			else { // ÂÒÎË Ì‡ ÒÚÓÍÂ ÌÂÚ ÌË Ó‰ÌÓÈ ;
				$properties[] = rtrim($line); // ì‰‡ÎﬂÂÏ ‚ÒÂ ÔÓ·ÂÎ˚ (\s) ‚ ÍÓÌˆÂ ÒÚÓÍË
			}

			foreach($properties as $key=>$val) if(trim($val)=='') unset($properties[$key]); // ËÁ·‡‚ÎﬂÂÏÒﬂ ÓÚ ÔÛÒÚ˚ı ˝ÎÂÏÂÌÚÓ‚ ÔÓÎÛ˜ÂÌÌ˚ı ‚ ÂÁÛÎ¸Ú‡ÚÂ explode(";", $line);

			foreach($properties as $property){
				$index = null; // ÑÂÙÓÎÚÌÓÂ ÁÌ‡˜ÂÌËÂ ËÌ‰ÂÍÒ‡ ÔÓﬂ‰Í‡ ‰Îﬂ Ò‚ÓÈÒÚ‚‡. ÖÒÎË Ò‚ÓÈÒÚ‚Ó ÌÂ ÁÌ‡ÍÓÏÓ, ÚÓ index Ú‡Í Ë ÓÒÚ‡ÌÂÚÒﬂ null.

				if(!is_array($this->sort_order[0])){ // ÖÒÎË ÔÓﬂ‰ÓÍ ÒÓÚËÓ‚ÍË ÌÂ ‡Á·ËÚ Ì‡ „ÛÔÔ˚ Ò‚ÓÈÒÚ‚
					foreach($this->sort_order as $pos=>$key){
						if(strpos(' '.trim($property), ' '.$key.':')!==false) $index = $pos;
					}
				}
				else{
					foreach($this->sort_order as $pos=>$key){ // ‰Îﬂ Í‡Ê‰ÓÈ „ÛÔÔ˚ Ò‚ÓÈÒÚ‚
						foreach($this->sort_order[$pos] as $p=>$k){ // ‰Îﬂ Í‡Ê‰Ó„Ó Ò‚ÓÈÒÚ‚‡
							if(strpos(' '.trim($property),' '.$k.':')!==false){
								$through_number = $this->get_through_number($k); // ÓÔÂ‰ÂÎﬂÂÏ "ÒÍ‚ÓÁÌÓÈ" ÔÓﬂ‰ÍÓ‚˚È ÌÓÏÂ
								if($through_number!==false) $index = $through_number;
							}
						}
					}
				}

				if(count($lines)>1){
					if($index === null OR strpos($property, 'exp')) $undefined[] = $property.';';
					else{
						/*
						   ÑÓ·‡‚ÎﬂÂÚ Í ÛÊÂ ÒÛ˘ÂÒÚ‚Û˛˘ÂÈ Á‡ÔËÒË Ò ÓÔÂ‰ÂÎÂÌÌÓÏ ÔÓﬂ‰ÍÓ‚˚Ï ÌÓÏÂÓÏ Â˘Â Ó‰ÌÛ Á‡ÔËÒ¸ Ò Ú‡ÍËÏ ÊÂ ÔÓﬂ‰ÍÓ‚˚Ï ÌÓÏÂÓÏ
						   ÎË·Ó ÒÓÁ‰‡ÂÚ ÌÓ‚Û˛ Á‡ÔËÒ¸ ÂÒÎË Ò Ú‡ÍËÏ ÔÓﬂ‰ÍÓ‚˚Ï ÌÓÏÂÓÏ ÌË˜Â„Ó Â˘Â ÌÂ ‚ÒÚÂ˜‡ÎÓÒ¸
						*/
						if(isset($resorted[$index])) $resorted[$index] .= "\n".$property.';';
						else $resorted[$index] = $property.';';
					}
				}
				else{
					if($index === null OR strpos($property, 'exp')) $undefined[] = "\t".trim($property).';';
					else $resorted[$index] = "\t".trim($property).';';
				}
			}
		}

		ksort($resorted); // ÒÓÚËÛÂÏ ÔÓ ÍÎ˛˜‡Ï
		if(is_array($this->sort_order[0]) AND count($resorted)>0) $resorted = $this->separate_property_group($resorted); // ÖÒÎË Ò‚ÓÈÒÚ‚‡ ‡Á‰ÂÎÂÌ˚ Ì‡ „ÛÔÔ˚

		if(is_array($this->sort_order[0]) AND count($undefined)>0) $undefined[0] = "\n".$undefined[0];
		$undefined[count($undefined)] = $last; // ·ÂÂÊÌÓ ÒÓı‡ÌﬂÂÏ ÙÓÏ‡ÚËÓ‚‡ÌËÂ ÔÂÂ‰ }

		$resorted = array_merge($resorted, $undefined); // ‰Ó·‡‚ÎﬂÂÏ ‚ ÍÓÌÂˆ ÌÂ‡ÒÔÓÁÌ‡ÌÌÓÂ

		if(isset($expressions) AND count($expressions)>0){ // ÂÒÎË ·˚ÎË Ó·Ì‡ÛÊÂÌ˚ Ë ‚˚ÂÁ‡Ì˚ expression
			foreach($resorted as $num=>$line){
				foreach($expressions as $key=>$val){
					if(strpos($line, 'exp'.$key)) $resorted[$num] = str_replace('exp'.$key, 'expression('.$val.')', $line); // Á‡ÏÂÌﬂÂÏ ÁÌ‡˜ÂÌËÂ expression Ó·‡ÚÌÓ
				}
			}
		}

		return $resorted;
	}

	/**
	 * ÇÓÁ‚‡˘‡ÂÚ ÒÍ‚ÓÁÌÓÈ Ôﬂ‰ÍÓ‚˚È ÌÓÏÂ ˝ÎÂÏÂÌÚ‡ ‰‚ÛÏÂÌÓ„Ó Ï‡ÒÒË‚‡ Ú‡Í, Í‡Í ÂÒÎË ·˚ ˝ÚÓÚ Ï‡ÒÒË‚ ·˚Î Ó‰ÌÓÏÂÌ˚Ï
	 * @param  {string}
	 * @return {bool|int}
	 */
	private function get_through_number($value){
		$i = 0;
		foreach($this->sort_order as $property_group){
			foreach($property_group as $key=>$val){
				if($val==$value) return $i;
				else $i++;
			}
		}
		return false;
	}

	/**
	 * ê‡Á‰ÂÎﬂÂÚ Ò‚ÓÈÒÚ‚‡ Ì‡ „ÛÔÔ˚ ÔÛÒÚÓÈ ÒÚÓÍÓÈ
	 * ÇÌËÏ‡ÌËÂ: ‚˚Á˚‚‡Ú¸ ÚÓÎ¸ÍÓ ÍÓ„‰‡ ÂÒÚ¸ ‡Á‰ÂÎÂÌËÂ Ì‡ „ÛÔÔ˚, ËÌ‡˜Â ‚ÂÌÂÚ ‚ıÓ‰ÌÓÈ Ï‡ÒÒË‚ ·ÂÁ ËÁÏÂÌÂÌËÈ
	 * @param  {array}
	 * @return {array}
	 */
	private function separate_property_group($properties){
		if(is_array($this->sort_order[0])){ // ÖÒÎË ‚ Ì‡ÒÚÓÈÍ‡ı ÌÂÚ ‡Á·ËÂÌËﬂ Ì‡ „ÛÔÔ˚, ÚÓ ‚˚ıÓ‰ËÏ ‚ıÓ‰ÌÓÈ Ï‡ÒÒË‚ ·ÂÁ ËÁÏÂÌÂÌËÈ
			foreach($properties as $key=>$property){
				$array = explode(':', $property);
				$prop_name[$key] = trim($array[0]);
			}
			foreach($this->sort_order as $group_num=>$property_group){ // èÂÂ·Ë‡ÂÏ „ÛÔÔ˚ Ò‚ÓÈÒÚ‚
				$intersect = array_intersect($prop_name, $property_group);
				if(count($intersect)>0){
					$num = array_keys($intersect);
					$last_key = null;
					foreach($num as $n)	$last_key = $n;
					if($properties[$last_key] != end($properties)) $properties[$last_key] = $properties[$last_key]."\n";
				}
			}
		}
		return $properties;
	}

}
function getExtension($filename) {
    return substr(strrchr($fileName, '.'), 1);
  }

function DirFilesR($dir,$types='')
  {
	
		$files = Array();
		if($handle = opendir($dir))
		{
	    
		  while (false !== ($file = readdir($handle)))
		  {
		    if ($file != "." && $file != "..")
		    {
		      if(is_dir($dir."/".$file))
			$files = array_merge($files,DirFilesR($dir."/".$file,$types));
		      else
		      {
			$pos = strrpos($file,".");
			$ext = substr($file,$pos,strlen($file)-$pos);
	    
			if($types)
			{
			    // Если указаны расширения
			    // то смотрим расширение текущего файла
			    // и сверяем с требуемыми
			  if(in_array($ext,explode(';',$types)))
			    $files[] = $dir."/".$file;
			}
			else
			    // А если не указаны,
			    // то добавляем без проверок
			  $files[] = $dir."/".$file;
		      }
		    }
		  }
		  closedir($handle);
		}
		
		return $files;


  } // function DirFilesR($dir,$types='')

  

//print_r (DirFilesR($argv[1]));

//print_r (DirFilesR($argv[1],'.css'));

//echo "!!!!" . strlen($argv[1]);
//echo  substr($argv[1],strlen($argv[1])-4,strlen($argv[1]));

//echo substr($argv[1],strlen($argv[1])-4,strlen($argv[1]));

//echo $argv[1];

if (substr($argv[1],strlen($argv[1])-4,strlen($argv[1]))!=".css")
{
	foreach (DirFilesR($argv[1],'.css') as $k )
	{
	    $input = file_get_contents($k);
	    $csscomb = new CSScomb();
	    $input=$csscomb->do_resort($input);
	    file_put_contents($k, $input);
	};	
}
else
{
	$input = file_get_contents($argv[1]);
	$csscomb = new CSScomb();
	$input=$csscomb->do_resort($input);
	//echo $input;
	file_put_contents($argv[1], $input);
}


?>