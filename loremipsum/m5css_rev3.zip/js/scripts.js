/**
 * @author <a href="http://meia5.com">Media5</a> - <a href="mailto:banzalik@media5.com">Бойченко Александр</a>
 * @description скрипты для m5 css framework
 */
 
 /**
 * @description полная загрузка страницы, картинки при этом уже загрузились
 */
window.onload=documentLoaded; // присваиваем функцию documentLoaded

/**
 * @description вызов функций при полной загрузке страницы, картинки при этом уже загрузились
 */
function documentLoaded(){
	
}


/**
 * @description вызов функций при полной загрузке DOM дерева, картинки при этом еще не загрузились
 */
$(document).ready(function(){
			autoclearInput();
			
						   
})


/**
 * @description очистка инпутов, при клике на них
 */
function autoclearInput(){
	$(".autoclear").each(function(){
		$(this).attr("defaultvalue",$(this).attr("value")); // записываем в defaultvalue значение по умолчанию, необходимо для проверки нового стекста со старым
	});

	$(".autoclear").click(function(){ 
		if ($(this).attr("value")==$(this).attr("defaultvalue")) { // проверяем совпадают ли value и defaultvalue
			$(this).attr("value", ""); // сбрасываем значение value
		}
	})
}